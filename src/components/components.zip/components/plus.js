'use strict';
import React from 'react'; 
import{
  StyleSheet,
  PropTypes,
  Text,
  TouchableOpacity,
  View,
  Image
} from 'react-native';

import StyleVars from 'funshare/StyleVars';
import Routes from 'funshare/Routes';

const styles = StyleSheet.create({

});

class Ico extends React.Component {
  render() {
    let style = {height:25 , width: 25, marginRight:8 , marginTop:14};
    return (
      <TouchableOpacity
        style={this.props.style}
        activeOpacity={0.5}
        onPress={this.goAddsuff.bind(this)}
      >
        <Image style={style}
        resizeMode={Image.resizeMode.contain}
        source={require('../img/plus.png')}
         />
      </TouchableOpacity>
     );
  }


 goAddsuff() {
  
  this.props.replaceRoute(Routes.addstuff());
  
}
}

export default Ico;
